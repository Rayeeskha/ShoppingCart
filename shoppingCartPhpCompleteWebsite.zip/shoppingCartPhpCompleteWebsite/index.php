<?php include "includes/header.php"; ?>
	<body>
		<div class="container-fluid">
			
			
				
				<div align="left">
					<button type="button" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-primary btn-lg">Add Category</button>
				</div>
				<br /><br />

				
				<table id="user_data" class="table table-striped">
					<thead>
						<tr>
							
							<th >Category Name</th>
							<th >Description</th>
							<th >Status</th>
							<th >Category Image</th>
							<th >Edit</th>
							<th >Delete</th>
						</tr>
					</thead>
				</table>
				
			
		</div>
	</body>
</html>

<div id="userModal" class="modal fade">
	<div class="modal-dialog">
		<form method="post" id="user_form" enctype="multipart/form-data">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add Category</h4>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label>Category Name</label>
						<input type="text" name="category_name" id="category_name" class="form-control" placeholder="Category Name" required="" />
					</div>
					<div class="form-group">
						<label>Status</label>
						<select id="status" name="status" class="form-control" required="">
							<option value="Available">Available</option>
							<option value="NotAvailable">NotAvailable</option>
						</select>
					</div>
					<div class="form-group">
						<label>Description</label>
						<textarea type="text" name="description" id="description" class="form-control" placeholder="Description"></textarea>  
					</div>
					<div class="form-group">
						<label>Select Category Image</label>
						<input type="file" name="user_image" id="user_image" class="form-control" />
						<span id="user_uploaded_image"></span>
					</div>
				</div>
				<div class="modal-footer">
					<input type="hidden" name="user_id" id="user_id" />
					<input type="hidden" name="operation" id="operation" />
					<input type="submit" name="action" id="action" class="btn btn-primary" value="Add" />
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</form>
	</div>
</div>

<!---Script --->

<script type="text/javascript">
	
$(document).ready(function(){
	$('#add_button').click(function(){
		$('#user_form')[0].reset();
		$('.modal-title').text("Add Category");
		$('#action').val("Add");
		$('#operation').val("Add");
		$('#user_uploaded_image').html('');
	});
	
	var dataTable = $('#user_data').DataTable({
		"processing":true,
		"serverSide":true,
		"order":[],
		"ajax":{
			url:"fetch.php",
			type:"POST"
		},
		"columnDefs":[
			{
				"targets":[0, 3, 4],
				"orderable":false,
			},
		],

	});

	$(document).on('submit', '#user_form', function(event){
		event.preventDefault();
		var category_name = $('#category_name').val();
		 var description = $('#description').val();
		var status = $('#status').val();
		var extension = $('#user_image').val().split('.').pop().toLowerCase();
		if(extension != '')
		{
			if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
			{
				alert("Invalid Image File");
				$('#user_image').val('');
				return false;
			}
		}	
		if(category_name != '' && status != '')
		{
			$.ajax({
				url:"insert.php",
				method:'POST',
				data:new FormData(this),
				contentType:false,
				processData:false,
				success:function(data)
				{
					alert(data);
					$('#user_form')[0].reset();
					$('#userModal').modal('hide');
					dataTable.ajax.reload();
				}
			});
		}
		else
		{
			alert("Both Fields are Required");
		}
	});
	
	$(document).on('click', '.update', function(){
		var user_id = $(this).attr("id");
		$.ajax({
			url:"fetch_single.php",
			method:"POST",
			data:{user_id:user_id},
			dataType:"json",
			success:function(data)
			{
				$('#userModal').modal('show');
				$('#category_name').val(data.category_name);
				$('#description').val(data.description);
				$('#status').val(data.status);
				$('.modal-title').text("Edit Category");
				$('#user_id').val(user_id);
				$('#user_uploaded_image').html(data.user_image);
				$('#action').val("Edit");
				$('#operation').val("Edit");
			}
		})
	});
	
	$(document).on('click', '.delete', function(){
		var user_id = $(this).attr("id");
		if(confirm("Are you sure you want to delete this?"))
		{
			$.ajax({
				url:"delete.php",
				method:"POST",
				data:{user_id:user_id},
				success:function(data)
				{
					alert(data);
					dataTable.ajax.reload();
				}
			});
		}
		else
		{
			return false;	
		}
	});
	
	
});

</script>