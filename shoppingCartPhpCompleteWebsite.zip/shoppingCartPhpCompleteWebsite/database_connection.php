<?php

$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=touchshopping', $username, $password );

?>