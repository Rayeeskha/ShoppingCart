<html>
	<head>
		<title>Touchronics Category</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-theme.min.css">
		<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>		
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

		   <link rel="stylesheet" type="text/css" href="assets/css/styles.min.css">


		<style>
			body
			{
				margin:0;
				padding:0;
				background-color:#f1f1f1;
			}
			.box
			{
				width:1270px;
				padding:20px;
				background-color:#fff;
				border:1px solid #ccc;
				border-radius:5px;
				margin-top:25px;
			}
		</style>
	</head>
		<div class="navbar navbar-default">
		<aside class="col-md-2 col-lg-2 col-sm-2 col-xs-3 ">

			<a href="#"><img src="assets/images/touchcronics.png" class="logoImg img-responsive"/></a>
		</aside>
	</div>

	<!---Navigation menu ----->
	<div class="icons">
    <div class="hidden-sm hidden-xs">
    	<div class="container">
    		<nav class="mainMenu1">
        		<ul class="mainMenu text-center">
        			<?php $baseName = basename( $_SERVER['PHP_SELF'] ); $color = 'style="color: #24B314"'; ?>
                    
        			<li><a href="../index.php"><i class="fa fa-sitemap" <?= preg_match("/categories/", $baseName ) ? $color : ''; ?>> </i><p>Categories</p></a></li>

        			<li><a href="../items/index.php" <?= preg_match("/items/", $baseName ) ? $color : ''; ?> ><i class="fas fa-luggage-cart"></i><p>Items</p></a></li>

        		</ul>
        		<div class="clearfix"></div>
        	</nav>
        </div>
    	<!--<div class="navBtn pull-right"><i class="fas fa-caret-square-down navBtnAct"></i></div>-->
    	<div class="clearfix"></div>
	</div>


  <div class="container" style="margin-top: 20px;">
        <div class="hidden-md hidden-lg visible-sm visible-xs">
            <button type="button" class="btn dropdown-toggle btn-primary pull-right mobileMenu_btn" data-toggle="dropdown" >
                <i class="fa fa-bars" aria-hidden="true"></i>
            </button>
            <div class="dropdown-menu pull-right" style="top:4%;right: 7px;">
                <nav class="mainMenu1 mobileMenu">
                    <ul class="mainMenu">
                    	<?php $baseName = basename( $_SERVER['PHP_SELF'] ); $color = 'style="color: #24B314"'; ?>
                    	<li><a href="items/index.php"><i class="fas fa-utensils" <?= preg_match("/items/", $baseName ) ? $color : ''; ?> ></i><span>Items</span></a></li>
                        <li><a href="#"><i class="fa fa-sitemap" <?= preg_match("/categories/", $baseName ) ? $color : ''; ?>> </i><span>Categories</span></a></li>


                   </ul>
            			<div class="clearfix"></div>
       			</nav>
            </div>
        </div>
    </div>
</div>