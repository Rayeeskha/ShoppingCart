<?php

//database_connection.php

$connect = new PDO('mysql:host=localhost;dbname=touchshopping', 'root', '');
// if ($connect) {
// 	# code...
// 	echo "connect";
// }else{
// 	echo "Not connected";
// }

?>