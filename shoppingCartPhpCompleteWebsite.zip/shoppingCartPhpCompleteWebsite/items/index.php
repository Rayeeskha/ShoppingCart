<?php include "header.php"; ?>
<div class="container-fluid">
		<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Items List
</button>
<a href="../Shopping/shop.php" class="btn btn-primary">ShoppingCart </a>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Items</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      	<!--Call to function --->
      	<?php items(); ?>

      	<form action="" method="post" enctype="multipart/form-data">
			<div class="form-group">
			    <label for="name">Item Name</label>
			    <input type="text" class="form-control" name="item_name" placeholder="Item Name">
			</div>

			<div class="form-group">
				<label for="category">Items Category</label>
				<select name="category_id" id="" class="form-control">

					<!---call to function --->
					<?php  select_category(); ?>
				</select>
			</div>

			<div class="form-group">
				<label>Status</label>
				<select name="status" id="" class="form-control">
				   
				    <option value="Available">Available</option>
				    <option value="Not Available">Not Available</option>

				</select>

			</div>

			<div class="form-group">
			    <label for="price">Items Price</label>
			    <input type="number" class="form-control" name="price" placeholder="Items Price">
			</div>
			<!-- <div class="form-group">
			    <label for="code">Product Code</label>
			    <input type="number" class="form-control" name="code" placeholder="Product Price" required="">
			</div> -->

			<div class="form-group">
			    <label for="image">Items Images</label>
			    <input type="file" class="form-control" name="image" multipart>
			</div>

			<div class="form-group">
			    <label for="video">Items Videos </label>
			    <input type="file" class="form-control" name="video" >
			</div>
			<div class="form-group">
				<label>Items Description</label>
				<textarea rows="5" cols="5" id="body" class="form-control" name="description" placeholder="Items Description"></textarea>
			</div>
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name="items_list" value="">Save Items</button>
      </div>
    </div>
  </div>
</div>
	</div>

</body>
</html>

