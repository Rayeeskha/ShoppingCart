<?php 

function items(){
	global $connection;
	if(isset($_POST['items_list'])){
	 global $connection;
		$item_name       = $_POST['item_name'];
		// $category_id     = $_POST['category_id'];
		$status          = $_POST['status'];
		$price           = $_POST['price'];
		// $code            = $_POST['code'];

		$items_image    =  $_FILES['image']['name'];
		$image_tmp      = $_FILES['image']['tmp_name'];

		move_uploaded_file( $image_tmp , "../images/$items_image" );

		$items_videos = $_FILES['video']['name'];
		$video_tmp   = $_FILES['video']['tmp_name'];

		move_uploaded_file($video_tmp, "../Videos/" .$items_videos);

		$description = $_POST['description'];

		$query = "INSERT INTO tbl_product(name,image,price,status,video,description)";

		$query .= "VALUES('{$item_name}','{$items_image}','{$price}','{$status}',  '{$items_videos}','{$description}')";

		$items_query = mysqli_query($connection,$query);

		// $result = mysqli_query($connection, $items_query);
		// $the_item_id = mysqli_insert_id($connection);
		// echo "<p class='bg-success'>Items List Created..<a href='items.php?p_id={$the_item_id}'>View Items List</a></p>";
		
	}

	function select_category(){
		global $connection;
			$category_query = "SELECT * FROM category";
			$result =mysqli_query($connection, $category_query);
			while ($row = mysqli_fetch_assoc($result)) {
				# code...
				$cat_id = $row['id'];
				$cat_name = $row['category_name'];

				echo "<option value='$cat_id'>{$cat_name}</option>";
			}
	}

}

?>