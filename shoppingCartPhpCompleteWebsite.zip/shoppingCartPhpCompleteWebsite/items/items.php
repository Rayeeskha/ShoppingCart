<?php include "header.php"; ?>


<div class="container-fluid">
	<a href="index.php" class="btn btn-info ">Back to Add Items</a>
	<a href="../Shopping/shop.php" class="btn btn-primary">Buy Know</a>
	<div class="col-md-12 col-lg-12 col-sm-12 col-xsm-12 col-xl-12">

		<?php
			

			 	$query = "SELECT  image, name, status, price, video, description FROM  tbl_product ";

			 	$select_all_items_query = mysqli_query($connection,$query);

			 	if (mysqli_num_rows($select_all_items_query) < 1) {
			 		# code...
			 		echo "<h1 class='text-danger'>Items Not Available</h1>";
			 	}else{
			 		while ($row = mysqli_fetch_array($select_all_items_query)) {
			 			# code...
			 		?>


			 		<div class="container">
			 			<div class="card">
			 				<div class="col-md-12 col-lg-12 col-sm-12 col-xsm-12 col-xl-12">
			 				<table class="table table-hover shopping-cart-wrap table-responsive">
			 					<thead class="text-muted">
			 						<tr>
									  <th scope="col">Product</th>
									  
									  <th scope="col">Product Videos</th>
									  <th scope="col" width="120">Quantity</th>
									  <th scope="col" width="120">Price</th>
									  <th scope="col" width="200" class="text-right">Action</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<figure class="media">
											    <div class="img-wrap ">
											    	<a href="../images/<?php echo $row[0] ?>">
											    	<img src="../images/<?php echo $row[0]; ?>" class="rounded mx-auto d-block" style="width: 200; height: 100">
											    	</a>
											    </div>
											    <figcaption class="media-body">
											        <h3 class="title "><?php echo $row[1]; ?></h3>
											        
											        <dl class="param param-inline small">
											          <dt>Status </dt>
											          <dd><?php echo $row[2]; ?></dd>
											       

											         </dl>
												</figcaption>
											</figure> 
										</td>
										<td>
											<figure class="media">
											    <div class="img-wrap">
											    	<video width="200" height="100" controls>
													  <source src="../videos/<?php echo $row[4]; ?>" type="video/mp4"></video>
													  
											    </div>
											    <figcaption class="media-body">
											        <h5 class="title "><?php echo $row[5]; ?></h5>
											       
											    </figcaption>
											</figure> 
											
										</td>
										<td> 
									      <div class="form-group">
											<input type="button" class="bg-primary" onclick="decrementValue()" value="-" />
											<input type="text" name="quantity" class="text-center" value="1" maxlength=" 2" max="30" size="1" id="number" />
											<input type="button" class="bg-primary" onclick="incrementValue()" value="+" />
										</div> 
									    </td>
									    <td>
									    	 <div class="price-wrap"> 
									            <var class="price text-primary" style="font-weight: bold;">$INR <?php echo $row['price']; ?></var> 
									            <small class="text-muted">(INR each)</small> 
									        </div>
									    	
									    </td>

									   
									    <td class="text-right"> 
										    <a title="" href="" class="btn btn-outline-success" data-toggle="tooltip" data-original-title="Save to Wishlist"></a> 
										    <a href="" class="btn btn-danger"> × Remove</a>
										</td>
									    
										
									</tr>
									
								</tbody>
			 				
			 			</div>
			 		</div>
			 	</div>

				 		




			 	<?php }
			 	}
			


		?>
	</div>
</div>

<script type="text/javascript">
	function incrementValue()
	{
		var value = parseInt(document.getElementById('number').value, 10);
			 value = isNaN(value) ? 0 : value;
				if(value<30){
					 value++;
						 document.getElementById('number').value = value;
				}
	}
		function decrementValue()
		{
			var value = parseInt(document.getElementById('number').value, 10);
				value = isNaN(value) ? 0 : value;
					if(value>1){
						value--;
						document.getElementById('number').value = value;
					 }
}
</script>