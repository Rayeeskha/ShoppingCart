<?php 

	$connection = mysqli_connect("localhost","root","","touchshopping");
	// if ($connection) {
	// 	# code...
	// 	echo "Connected";
	// }else{
	// 	echo "Not connected";
	// }
?>