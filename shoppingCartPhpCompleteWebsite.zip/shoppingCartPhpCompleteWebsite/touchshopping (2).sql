-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2020 at 07:12 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `touchshopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`, `description`, `status`, `image`) VALUES
(3, 'Jwellary', 'All Jwellary Products Available', 'Available', '1802653022.png'),
(4, 'Motor Cart', 'Available', 'Available', '1534277203.png');

-- --------------------------------------------------------

--
-- Table structure for table `items_tbl`
--

CREATE TABLE `items_tbl` (
  `id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `video` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_image`
--

CREATE TABLE `tbl_image` (
  `image_id` int(11) NOT NULL,
  `image_name` varchar(200) NOT NULL,
  `image_description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_image`
--

INSERT INTO `tbl_image` (`image_id`, `image_name`, `image_description`) VALUES
(1, 'Screenshot (1).png', ''),
(2, 'Screenshot (2) - Copy - Copy.png', ''),
(3, 'Screenshot (2) - Copy.png', ''),
(4, 'Screenshot (2).png', ''),
(5, 'Screenshot (3) - Copy.png', ''),
(6, 'Screenshot (3).png', ''),
(7, 'Screenshot (4) - Copy.png', ''),
(8, 'Screenshot (4).png', ''),
(9, 'Screenshot (5) - Copy.png', ''),
(10, 'Screenshot (5).png', ''),
(11, 'Screenshot (6).png', ''),
(12, 'Screenshot (7).png', ''),
(13, 'Screenshot (8).png', ''),
(14, 'Screenshot (9).png', ''),
(15, 'Screenshot (10).png', ''),
(16, 'Screenshot (11).png', ''),
(17, 'Screenshot (12).png', ''),
(18, 'Screenshot (13) - Copy.png', ''),
(20, 'Laptop.png', 'Laptop Available'),
(21, 'Screenshot (1)-1598688421.png', ''),
(22, 'Screenshot (2) - Copy - Copy-1233025599.png', ''),
(23, 'Screenshot (2) - Copy-172794468.png', ''),
(24, 'Screenshot (2)-949367307.png', ''),
(25, 'Screenshot (3) - Copy-1925805263.png', ''),
(26, 'Screenshot (3)-2070208697.png', ''),
(27, 'Screenshot (4) - Copy-1728241774.png', ''),
(28, 'Screenshot (4)-495866712.png', ''),
(29, 'Screenshot (5) - Copy-240848166.png', ''),
(30, 'Screenshot (5)-1752725051.png', ''),
(31, 'Screenshot (6)-938106678.png', ''),
(32, 'Screenshot (7)-116324.png', ''),
(33, 'Screenshot (8)-2020291041.png', ''),
(34, 'Screenshot (9)-1401230179.png', ''),
(35, 'Screenshot (10)-1479956949.png', ''),
(36, 'Screenshot (11)-458608346.png', ''),
(37, 'Screenshot (12)-308942967.png', ''),
(38, 'Screenshot (13) - Copy-1738202770.png', ''),
(39, 'Screenshot (13).png', ''),
(40, 'Shop.png', 'All variety is Available in the cart of the product'),
(41, 'Screenshot (1)-561601878.png', ''),
(42, 'Screenshot (2) - Copy - Copy-1569970198.png', ''),
(43, 'Screenshot (2) - Copy-1790116284.png', ''),
(44, 'Screenshot (2)-1428747119.png', ''),
(45, 'Screenshot (3) - Copy-1627318028.png', ''),
(46, 'Screenshot (3)-209766356.png', ''),
(47, 'Screenshot (4) - Copy-1644938968.png', ''),
(48, 'Screenshot (4)-1043890732.png', ''),
(49, 'Screenshot (5) - Copy-1735833528.png', ''),
(50, 'Screenshot (5)-1205004080.png', ''),
(51, 'Screenshot (6)-2125074590.png', ''),
(52, 'Screenshot (7)-1052236274.png', ''),
(53, 'Screenshot (8)-2129580816.png', ''),
(54, 'Screenshot (9)-784753758.png', ''),
(55, 'Screenshot (10)-2106218542.png', ''),
(56, 'Screenshot (11)-44949107.png', ''),
(57, 'Screenshot (12)-1639070437.png', ''),
(58, 'Screenshot (13) - Copy-1038991258.png', ''),
(59, 'Screenshot (13)-318993455.png', ''),
(60, 'Screenshot (14).png', ''),
(61, 'Screenshot (1)-559787661.png', ''),
(62, 'Screenshot (2) - Copy - Copy-648965933.png', ''),
(63, 'Screenshot (2) - Copy-294902.png', ''),
(64, 'Screenshot (2)-1503416230.png', ''),
(65, 'Screenshot (3) - Copy-781379072.png', ''),
(66, 'Screenshot (3)-2024768155.png', ''),
(67, 'Screenshot (4) - Copy-1525384186.png', ''),
(68, 'Screenshot (4)-99978786.png', ''),
(69, 'Screenshot (5) - Copy-999973846.png', ''),
(70, 'Screenshot (5)-754282121.png', ''),
(71, 'Screenshot (6)-822256101.png', ''),
(72, 'Screenshot (7)-995836740.png', ''),
(73, 'Screenshot (8)-1994453983.png', ''),
(74, 'Screenshot (9)-1169858727.png', ''),
(75, 'Screenshot (10)-1913276297.png', ''),
(76, 'Screenshot (11)-2128239159.png', ''),
(77, 'Screenshot (12)-2079074606.png', ''),
(78, 'Screenshot (13) - Copy-1995768230.png', ''),
(79, 'Screenshot (13)-26655507.png', ''),
(80, 'Screenshot (14)-1749260490.png', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL,
  `status` varchar(255) NOT NULL,
  `video` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `name`, `image`, `price`, `status`, `video`, `description`) VALUES
(7, 'Casmatics', 'Angels.jpg', 150.00, 'Available', 'Ajay_Devgan_Dailogues_from_Diljale.3gp', ''),
(8, 'Casmatics', 'Angels.jpg', 123.00, 'Available', '', ''),
(9, 'Casmatics', 'Angels.jpg', 123.00, 'Available', '', ''),
(10, 'Casmatics', 'Angels.jpg', 150.00, 'Available', 'Ajay_Devgan_Dailogues_from_Diljale.3gp', ''),
(11, 'Casmatics', 'Angels.jpg', 250.00, 'Available', 'Ajay_Devgan_Dailogues_from_Diljale.3gp', ''),
(12, 'jwellaryALL Products', 'Angels.jpg', 150456.00, 'Available', 'Armaan_Malik__Khali_Khali_Dil_Full_Song___Tera_Intezaar___Sunny_Leone___Arbaaz_K.mp4', ''),
(13, 'Apple phone', 'Screenshot (8).png', 1532.00, 'Available', '', ''),
(14, 'Realme2 pr', 'Screenshot (17).png', 12502.00, 'Available', '', 'Available in chpest price'),
(15, 'Casmatics', 'Screenshot (9).png', 1503.00, 'Available', 'Aayegi_Harpal_Tujhe_Meri_Yaad_HD_Song_(_Film_Andolan_).mp4', 'Best one '),
(16, 'Casmatics', 'Angels.jpg', 1245.00, 'Available', 'Aayegi_Harpal_Tujhe_Meri_Yaad_HD_Song_(_Film_Andolan_).mp4', ''),
(17, 'Apple phone', 'Angels.jpg', 2505456.00, 'Available', 'Ajay_Devgan_Dailogues_from_Diljale.3gp', ''),
(18, 'Motor', 'Screenshot (23).png', 56556165.00, 'Available', 'BAN_JA_TU_MERI_RANI___Murat_or_hayat_â€“_Tumhari_Sulu___Guru_Randhawa,_Vidya_Balan.mp4', ''),
(19, 'Laptop', 'Screenshot (8).png', 65403.00, 'Available', 'DILBAR_Lyrical___Satyameva_Jayate__John_Abraham,_Nora_Fatehi,Tanishk_B,_Neha_Kak.mp4', 'Available'),
(20, 'Cloths', 'Angels.jpg', 65123.00, 'Available', 'Ajay_Devgan_Dailogues_from_Diljale.3gp', ''),
(21, 'jwellaryALL Products collection', 'Screenshot (17).png', 250.00, 'Available', 'Diwane_ruk_ja_WhatsApp_status_(Ashiqui_banaya)_Neha_kakkar.mp4', ''),
(22, 'Doctor', 'Angels.jpg', 1501213.00, 'Available', 'Diwane_ruk_ja_WhatsApp_status_(Ashiqui_banaya)_Neha_kakkar.mp4', 'Best is one !...'),
(23, 'Casmatics', 'Angels.jpg', 150.00, 'Available', 'Patola_Lyrical_Video___Blackmail___Irrfan_Khan___Kirti_Kulhari___Guru_Randhawa.mp4', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items_tbl`
--
ALTER TABLE `items_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_image`
--
ALTER TABLE `tbl_image`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `items_tbl`
--
ALTER TABLE `items_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_image`
--
ALTER TABLE `tbl_image`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
